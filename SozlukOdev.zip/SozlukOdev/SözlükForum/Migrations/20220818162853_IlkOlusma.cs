﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SözlükForum.Migrations
{
    public partial class IlkOlusma : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Kullanicis",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    kullanıcıAd = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    sifre = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    admin = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kullanicis", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ForumSorus",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    soru = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    kullaniciid = table.Column<int>(type: "int", nullable: true),
                    eklemeTarih = table.Column<DateTime>(type: "datetime2", nullable: false),
                    icerik = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    katego = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ForumSorus", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ForumSorus_Kullanicis_kullaniciid",
                        column: x => x.kullaniciid,
                        principalTable: "Kullanicis",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Yorums",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Icerik = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    Zaman = table.Column<DateTime>(type: "datetime2", nullable: false),
                    kullaniciid = table.Column<int>(type: "int", nullable: false),
                    forumsoruId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Yorums", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Yorums_ForumSorus_forumsoruId",
                        column: x => x.forumsoruId,
                        principalTable: "ForumSorus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Yorums_Kullanicis_kullaniciid",
                        column: x => x.kullaniciid,
                        principalTable: "Kullanicis",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ForumSorus_kullaniciid",
                table: "ForumSorus",
                column: "kullaniciid");

            migrationBuilder.CreateIndex(
                name: "IX_Yorums_forumsoruId",
                table: "Yorums",
                column: "forumsoruId");

            migrationBuilder.CreateIndex(
                name: "IX_Yorums_kullaniciid",
                table: "Yorums",
                column: "kullaniciid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Yorums");

            migrationBuilder.DropTable(
                name: "ForumSorus");

            migrationBuilder.DropTable(
                name: "Kullanicis");
        }
    }
}
